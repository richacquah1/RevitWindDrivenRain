public class Ray
{
    // Properties and methods for ray direction, origin, etc.
}

public class RayHitResult
{
    // Properties and methods for storing ray hit results
    // Such as hit surface, hit point, etc.
}
